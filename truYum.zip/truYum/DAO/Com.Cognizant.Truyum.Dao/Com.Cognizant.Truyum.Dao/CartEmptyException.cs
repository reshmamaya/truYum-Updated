﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Cognizant.Truyum.Dao
{
   public class CartEmptyException:Exception
    {
        private string _msg;
        public CartEmptyException()
        {

        }
        public CartEmptyException(string _msg)
        {
            this.Msg = _msg;
        }

        public string Msg
        {
            get
            {
                return _msg;
            }

            set
            {
                _msg = value;
            }
        }
        public override string ToString()
        {
            return string.Format("{0}",this._msg);
        }
    }
}
