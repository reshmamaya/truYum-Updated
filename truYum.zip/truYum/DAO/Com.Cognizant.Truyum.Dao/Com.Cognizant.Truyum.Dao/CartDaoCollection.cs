﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Com.Cognizant.Truyum.Model;

namespace Com.Cognizant.Truyum.Dao
{
   public  class CartDaoCollection : ICartDao
    {
        private static Dictionary<long, Cart> _userCarts;
        public CartDaoCollection()
        {
            if(_userCarts==null)
            {
                _userCarts = new Dictionary<long, Cart>();

            }
        }
        public void AddCartItem(long userId, long menuItemId)
        {
            MenuItemDaoCollection menuDao = new MenuItemDaoCollection();
            MenuItem menuItem =menuDao.GetMenuItem(menuItemId);
            if (_userCarts.ContainsKey(userId))
            {
                _userCarts[userId].MenuItemList.Add(menuItem);
            }
            //else first create the userid and then product to user id
            else
            {
                Cart newCart = new Cart();
                //create  alist of menuItems whichu u want to svane in ur cart
                List<MenuItem> menuItems = new List<MenuItem>();
                menuItems.Add(menuItem);
                //add list to cart

                newCart.MenuItemList = menuItems;

                //add data to cart dictionary via id
                _userCarts.Add(userId, newCart);
            }
        }

        public Cart GetAllCartItems(long userId)
        {
            //create  anew cart under which  you will store items and total price
            Cart cart = new Cart();
            //check if the user id(key) is exixting in dictionary , if existing out the value from the dictionary

            bool check = _userCarts.TryGetValue(userId, out cart);
            //Tryget value will check under dictionary for a key if key found it will output value and result will be true,else false;



            //check if cart is empty or productList is not containing any items
            if(cart ==null|| cart.MenuItemList.Count==0)
            {
                throw new CartEmptyException("Exception:No item in the Cart");
            }
            //check if bool result is true;if true calculate the total price of items

            if(check)//i.e tue
            {
                //extract menu info from cart class and store under local list
                List<MenuItem> menuList = cart.MenuItemList;
                double totalPrice = 0;


                //Loop through all the menu present under the user id,extract price of each product and do total;
                foreach(MenuItem menu in menuList)
                {
                    totalPrice += menu.Price;
                }
                cart.Total = totalPrice;
            }

            return cart;
        }

        public void RemoveCartItem(long userId, long productId)
        {
            //serach data from product  via itemId and  remove  the product  from the cart for the user
            //extract all items tagged to auser id and place it under local collection
            List<MenuItem> menuList = _userCarts[userId].MenuItemList;
            //removal
            for(int i=0;i<menuList.Count;i++)
            {
                if(menuList[i].Id==productId)
                {
                    menuList.RemoveAt(i);
                }
            }
        }
    }
}
